import React from 'react';
import { StyleSheet, Text, View, Image, TouchableOpacity, ScrollView, Button} from 'react-native';

export default function App() {
  console.disableYellowBox = true;
  //return 구문 밖에서는 슬래시 두개 방식으로 주석
  
  return (
      <View>
          <Text>미팅 등록이 완료되었습니다.</Text>
          
      </View>

  )
  
}